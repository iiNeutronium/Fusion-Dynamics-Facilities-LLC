# Fusion Dynamics Research and Power Generation

## Overview

This is a modern full-stack web application built for a fusion reactor simulation game called "Fusion Dynamics Research and Power Generation". The application features a futuristic gaming website with sections for game features, screenshots, company information, downloads, and contact forms. It's built using React with TypeScript on the frontend and Express.js on the backend, with a PostgreSQL database managed through Drizzle ORM.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **Styling**: Tailwind CSS with custom design system featuring futuristic/electric themes
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state management
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **API Design**: RESTful API structure with `/api` prefix routing
- **Middleware**: Custom logging middleware for API requests
- **Error Handling**: Centralized error handling middleware

### Database Architecture
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Connection**: Neon Database serverless PostgreSQL connection

## Key Components

### Frontend Components
- **Navigation**: Fixed navigation with smooth scrolling and active section highlighting
- **Hero Section**: Animated landing section with gradient backgrounds and floating elements
- **Features Section**: Interactive feature showcase with icons and descriptions
- **Screenshots Section**: Image gallery showcasing game visuals
- **About Section**: Company information with statistics
- **Download Section**: Platform-specific download options
- **Contact Section**: Contact form with validation and toast notifications
- **Footer**: Comprehensive site links and company information

### Backend Components
- **Storage Interface**: Abstract storage interface with in-memory implementation
- **Route Registration**: Modular route registration system
- **Vite Integration**: Development server integration with HMR support

### Database Schema
- **Users Table**: Basic user management with username/password fields
- **Validation**: Zod schemas for type-safe data validation

## Data Flow

1. **Client Requests**: React components make API calls using TanStack Query
2. **API Processing**: Express server handles requests through registered routes
3. **Data Storage**: Storage interface abstracts database operations
4. **Response Handling**: Structured JSON responses with error handling
5. **State Management**: Client-side state synchronized with server through React Query

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for serverless environments
- **@tanstack/react-query**: Server state management and caching
- **drizzle-orm**: Type-safe database operations
- **@radix-ui/***: Accessible UI primitive components
- **wouter**: Lightweight React router
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **vite**: Fast build tool and development server
- **typescript**: Type safety across the application
- **drizzle-kit**: Database schema management and migrations

## Deployment Strategy

### Development Environment
- **Hot Module Replacement**: Vite provides instant feedback during development
- **Replit Integration**: Custom plugins for Replit development environment
- **Environment Variables**: DATABASE_URL required for database connection

### Production Build
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations handle schema updates
- **Static Serving**: Express serves built frontend assets in production

### Environment Configuration
- **Development**: tsx for TypeScript execution with hot reloading
- **Production**: Compiled JavaScript execution with static asset serving
- **Database**: PostgreSQL connection via environment variable

The application follows a modern full-stack architecture with clear separation of concerns, type safety throughout, and a focus on developer experience and performance.